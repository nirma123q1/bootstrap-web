# Halaman Web dengan Bootstrap

Proyek ini merupakan contoh halaman web statis menggunakan Bootstrap 5.

## Fitur

- Navbar responsif
- Carousel dengan 3 gambar
- 3 buah Card layanan
- Tabel pengunjung
- Footer

## Teknologi
- HTML5
- Bootstrap 5 (via CDN)

## Cara Menjalankan
1. Download atau clone repository ini
2. Buka `index.html` di browser

## Hak Cipta
&copy; 2025 - Dibuat untuk tugas pemrograman web